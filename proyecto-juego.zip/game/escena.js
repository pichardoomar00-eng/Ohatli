import * as THREE from 'three';
import {PointerLockControls} from 'three/PointerLockControls';

//🕹️🕹️ Renderer - Realiza una conexión entre el código y el canvas
export const renderer = new THREE.WebGLRenderer({
    canvas: document.getElementById('myCanvas'), antialias: true,
});
renderer.setPixelRatio(window.devicePixelRatio);
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setClearColor(0x000000);

// 🎬 Creando nueva escena - Es el espacio donde se colocan los objetos
export const scene = new THREE.Scene();

//🎥🎥 Agregar una cámara de perspectiva
export const camera = new THREE.PerspectiveCamera(70, window.innerWidth / window.innerHeight, 0.1, 2000);
scene.add(camera);
camera.position.set(0, 25, 50);

// Controles de primera persona (el bloqueo del mouse lo disparan los
// botones "Jugar"/"Reanudar" del menú, ver menu.js)
export const controls = new PointerLockControls(camera, document.body);

// 🌸🌸 ejes (ocultos: su material ignora la luz, se verían en todo el mapa)
const ejes = new THREE.AxesHelper(50);
ejes.visible = false;
scene.add(ejes);

//🪻🪻 grid (oculto por el mismo motivo)
const grid = new THREE.GridHelper(50, 20);
grid.visible = false;
scene.add(grid);

// que la vista no se deforme si cambia el tamaño de la ventana
window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
});
