import {controls} from './escena.js';
import {estado} from './estado.js';
import {terrenoListo} from './terreno.js';
import {enemigosListos} from './enemigos.js';
import {monedasListas} from './monedas.js';
import {armasListas} from './armas.js';
import {botiquinesListos} from './botiquines.js';
import {checkpointsListos} from './checkpoints.js';

const menuInicio = document.getElementById('menu-inicio');
const menuPausa = document.getElementById('menu-pausa');
const menuCreditos = document.getElementById('menu-creditos');
const botonJugar = document.getElementById('boton-jugar');
const botonReanudar = document.getElementById('boton-reanudar');
const botonCreditos = document.getElementById('boton-creditos');
const botonVolverCreditos = document.getElementById('boton-volver-creditos');

// 🧱 mientras el terreno (y todo lo que depende de él) no termine de cargar,
// no se puede jugar — si no, todo aparecería amontonado en el origen
botonJugar.disabled = true;
botonJugar.textContent = 'Cargando terreno...';

const todoListo = Promise.all([
    terrenoListo,
    enemigosListos,
    monedasListas,
    armasListas,
    botiquinesListos,
    checkpointsListos,
]);

todoListo.then(() => {
    botonJugar.disabled = false;
    botonJugar.textContent = 'Jugar';
}).catch((error) => {
    botonJugar.textContent = 'Error al cargar el terreno';
    console.error('No se pudo cargar el terreno del nivel:', error);
});

botonJugar.addEventListener('click', () => {
    menuInicio.classList.add('oculto');
    estado.juegoIniciado = true;
    controls.lock();
});

botonReanudar.addEventListener('click', () => {
    controls.lock();
});

botonCreditos.addEventListener('click', () => {
    menuInicio.classList.add('oculto');
    menuCreditos.classList.remove('oculto');
});

botonVolverCreditos.addEventListener('click', () => {
    menuCreditos.classList.add('oculto');
    menuInicio.classList.remove('oculto');
});

// el navegador libera el mouse solo (ej. al presionar Escape) — ahí se pausa
controls.addEventListener('unlock', () => {
    if(!estado.juegoIniciado || estado.juegoTerminado) return; // aún no arranca, o ya terminó (GAME OVER)
    estado.pausado = true;
    menuPausa.classList.remove('oculto');
});

controls.addEventListener('lock', () => {
    estado.pausado = false;
    menuPausa.classList.add('oculto');
});
