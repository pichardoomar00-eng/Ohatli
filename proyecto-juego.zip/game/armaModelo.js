import * as THREE from 'three';
import {cargarModeloClonado} from './modelos.js';
import {catalogoArmas} from './catalogoArmas.js';

// 🧭🧭 Los modelos de Blender llegan en cualquier tamaño y orientación (la
// alabarda mide ~18 unidades, el machete ~31, y cada uno "apunta" hacia un
// eje distinto). Esta función los normaliza para que TODAS las armas queden
// igual: la punta hacia -Z (hacia el frente), el mango en el origen (0,0,0),
// y con el largo que pidas. Así, agregar un arma nueva no requiere medir nada.

const EJES = ['x', 'y', 'z'];

// mide qué tan ancho es el modelo en cada extremo de su eje largo.
// La punta (hoja / cabeza de hacha) es el extremo más ancho; el mango, el más delgado.
function medirAnchoDeExtremos(modelo, caja, tam, eje){
    const otros = EJES.filter((e) => e !== eje);
    const nuevo = () => ({min: [Infinity, Infinity], max: [-Infinity, -Infinity]});
    const extremos = [nuevo(), nuevo()];
    const v = new THREE.Vector3();

    modelo.traverse((hijo) => {
        if(!hijo.isMesh) return;
        const pos = hijo.geometry.attributes.position;
        for(let i = 0; i < pos.count; i++){
            v.fromBufferAttribute(pos, i).applyMatrix4(hijo.matrixWorld);
            const t = (v[eje] - caja.min[eje]) / tam[eje];
            const extremo = t < 0.2 ? extremos[0] : (t > 0.8 ? extremos[1] : null);
            if(!extremo) continue;
            for(let k = 0; k < 2; k++){
                const valor = v[otros[k]];
                if(valor < extremo.min[k]) extremo.min[k] = valor;
                if(valor > extremo.max[k]) extremo.max[k] = valor;
            }
        }
    });

    const ancho = (e) => Math.max(e.max[0] - e.min[0], e.max[1] - e.min[1]);
    return [ancho(extremos[0]), ancho(extremos[1])];
}

// tipo: 'machete' | 'alabarda' | ... (las llaves de catalogoArmas)
// largoObjetivo: largo final del arma en unidades del juego
// conBrillo: true para el arma en tu mano (se ve aunque la luz esté baja)
export async function crearModeloArma(tipo, largoObjetivo, conBrillo = false){
    const def = catalogoArmas[tipo];
    const {modelo} = await cargarModeloClonado(def.archivo);

    // 🎨 materiales: se reconstruyen. Un modelo SIN material (como la alabarda)
    // recibe de glTF un metal puro que, sin mapa de entorno, se ve NEGRO.
    modelo.traverse((hijo) => {
        if(!hijo.isMesh) return;
        const color = def.color !== undefined
            ? new THREE.Color(def.color)
            : (hijo.material.color ? hijo.material.color.clone() : new THREE.Color(0xcccccc));
        hijo.material = new THREE.MeshStandardMaterial({color, metalness: 0.25, roughness: 0.55, side: THREE.DoubleSide});
        if(conBrillo){
            hijo.material.emissive.copy(color);
            hijo.material.emissiveIntensity = 0.45;
        }
    });

    // 📏 eje largo del modelo y cuál de sus dos extremos es la punta
    modelo.updateMatrixWorld(true);
    const caja = new THREE.Box3().setFromObject(modelo);
    const tam = caja.getSize(new THREE.Vector3());

    let eje = 'x';
    for(const e of EJES){
        if(tam[e] > tam[eje]) eje = e;
    }

    const [anchoMin, anchoMax] = medirAnchoDeExtremos(modelo, caja, tam, eje);
    let puntaEnMax = anchoMax >= anchoMin;
    if(def.invertir) puntaEnMax = !puntaEnMax;

    const direccionPunta = new THREE.Vector3();
    direccionPunta[eje] = puntaEnMax ? 1 : -1;

    // 🔄 gira el modelo para que la punta apunte hacia -Z
    const rotador = new THREE.Group();
    rotador.add(modelo);
    rotador.quaternion.setFromUnitVectors(direccionPunta, new THREE.Vector3(0, 0, -1));
    if(def.rollGrados){
        const roll = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 0, 1), THREE.MathUtils.degToRad(def.rollGrados));
        rotador.quaternion.premultiply(roll);
    }

    // 📍 centra el arma y pone el mango en el origen; luego escala al largo pedido
    const contenedor = new THREE.Group();
    contenedor.add(rotador);
    contenedor.updateMatrixWorld(true);

    const caja2 = new THREE.Box3().setFromObject(contenedor);
    const tam2 = caja2.getSize(new THREE.Vector3());

    rotador.position.set(
        -(caja2.min.x + caja2.max.x) / 2,
        -(caja2.min.y + caja2.max.y) / 2,
        -caja2.max.z
    );
    contenedor.scale.setScalar(largoObjetivo / tam2.z);

    console.log(`🗡️ ${def.nombre}: eje largo ${eje}, punta en ${puntaEnMax ? '+' : '-'}${eje}, escala ${(largoObjetivo / tam2.z).toFixed(3)}`);
    return contenedor;
}
