import * as THREE from 'three';
import {GLTFLoader} from 'three/GLTFLoader';
import {scene} from './escena.js';

// 🧊🧊 cargador de modelos 3D (.glb / .gltf) — para los modelos que exportes de Blender
const cargador = new GLTFLoader();

// carga un modelo y lo agrega a la escena.
// ruta: dónde está el archivo .glb/.gltf (ej. './models/mi_modelo.glb')
// posicion: {x, y, z} dónde colocarlo
// escala: número o {x, y, z} — casi siempre vas a necesitar ajustar esto,
//         los modelos exportados de Blender rara vez salen ya al tamaño correcto
export function cargarModelo(ruta, posicion = {x: 0, y: 0, z: 0}, escala = 1){
    return new Promise((resolve, reject) => {
        cargador.load(
            ruta,
            (gltf) => {
                const modelo = gltf.scene;
                modelo.position.set(posicion.x, posicion.y, posicion.z);

                if(typeof escala === 'number'){
                    modelo.scale.setScalar(escala);
                } else {
                    modelo.scale.set(escala.x, escala.y, escala.z);
                }

                scene.add(modelo);
                console.log(`✅ modelo cargado: ${ruta}`, modelo);
                resolve(modelo);
            },
            undefined, // progreso de carga (opcional, no lo necesitamos por ahora)
            (error) => {
                console.error(`❌ no se pudo cargar el modelo: ${ruta}`, error);
                reject(error);
            }
        );
    });
}

// 🗃️🗃️ caché de modelos: cada archivo se descarga UNA sola vez (la promesa queda
// guardada) y de ahí se sacan copias independientes. Sirve para el pato, las
// armas, y cualquier modelo futuro.
const plantillas = new Map();

function obtenerPlantilla(ruta){
    if(!plantillas.has(ruta)){
        plantillas.set(ruta, new Promise((resolve, reject) => {
            cargador.load(ruta, (gltf) => resolve(gltf.scene), undefined, (error) => {
                console.error(`❌ no se pudo cargar el modelo: ${ruta}`, error);
                reject(error);
            });
        }));
    }
    return plantillas.get(ruta);
}

// descarga el modelo por adelantado (sin sacar copia). Úsala para que el menú
// espere a que estén listos y un archivo faltante avise desde el inicio.
export function precargarModelo(ruta){
    return obtenerPlantilla(ruta);
}

// devuelve una copia independiente del modelo, con sus propios materiales
// clonados (así se puede teñir una copia sin afectar a las demás), sin
// agregarla a la escena: quien la pida decide dónde ponerla.
export async function cargarModeloClonado(ruta){
    const plantilla = await obtenerPlantilla(ruta);
    const copia = plantilla.clone();

    const materiales = [];
    copia.traverse((hijo) => {
        if(hijo.isMesh){
            hijo.material = hijo.material.clone();
            hijo.material.userData.colorOriginal = hijo.material.color.clone();
            materiales.push(hijo.material);
        }
    });

    return {modelo: copia, materiales};
}

// 🦆🦆 el pato de muestra se usa como el modelo visual de los enemigos (ver enemigos.js)
export function cargarPatoClonado(){
    return cargarModeloClonado('./models/Duck.glb');
}
