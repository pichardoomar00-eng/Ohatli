import * as THREE from 'three';
import {scene, camera} from './escena.js';
import {cubo} from './jugador.js';
import {estado} from './estado.js';
import {alturaSuelo, terrenoListo} from './terreno.js';

// 🚩🚩 posiciones elegidas a mano (x, z) — ajusta/agrega conforme vayan
// llegando más islas. La altura (Y) se calcula sola con el rayo apenas
// carga el terreno, así no hay que medirla a mano.
const posicionesCheckpoint = [
    {x: 8, z: 8},
    {x: -8, z: -8},
];

const colorInactivo = 0x778da9;
const colorActivo = 0x2ecc71;
const distanciaActivacion = 5;

function crearCheckpoint(x, y, z){
    const geometria = new THREE.CylinderGeometry(0.4, 0.4, 6, 12);
    const material = new THREE.MeshStandardMaterial({color: colorInactivo});
    const poste = new THREE.Mesh(geometria, material);
    poste.position.set(x, y + 3, z); // parado sobre la isla
    scene.add(poste);
    return poste;
}

export const checkpoints = []; // se llena una vez que el terreno termine de cargar

export const checkpointsListos = terrenoListo.then(() => {
    for(let i = 0; i < posicionesCheckpoint.length; i++){
        const {x, z} = posicionesCheckpoint[i];
        const y = alturaSuelo(x, z);
        if(y === null) continue; // esa posición cayó fuera de cualquier isla: se omite
        checkpoints.push(crearCheckpoint(x, y, z));
    }
});

// se llama una vez por frame: si estás cerca de un checkpoint, lo activa
export function actualizarCheckpoints(){
    for(let i = 0; i < checkpoints.length; i++){
        const checkpoint = checkpoints[i];
        const distancia = cubo.position.distanceTo(checkpoint.position);
        if(distancia < distanciaActivacion){
            checkpoint.material.color.set(colorActivo);
            estado.checkpoint = {
                x: camera.position.x,
                y: camera.position.y,
                z: camera.position.z,
            };
        }
    }
}
