// 🗡️🗡️ catálogo de armas: TODO lo que distingue a una arma de otra vive aquí.
// Para agregar una arma nueva: copia un bloque, cambia el archivo y los números.
//
//   nombre         → lo que se muestra en el HUD
//   archivo        → ruta del modelo .glb
//   durabilidad    → cuántos golpes aguanta antes de romperse (conecten o no)
//   cooldown       → segundos mínimos entre un golpe y el siguiente (menos = más rápida)
//   duracionSwing  → segundos que dura la animación del golpe (debe ser ≤ cooldown)
//   rango          → a qué distancia alcanza a pegarle a un enemigo
//   largoVista     → qué tan larga se ve en tu mano (unidades del juego)
//   largoMapa      → qué tan larga se ve tirada en el mapa
//   pose           → dónde/cómo la sostienes: pos [x, y, z] y rot [x, y, z] (radianes)
//
// Opcionales:
//   color          → fuerza un color (útil si el modelo viene sin material, como la alabarda)
//   invertir       → true si el modelo queda con el mango hacia adelante en vez de la punta
//   rollGrados     → gira el arma sobre su propio eje largo (para cambiar qué cara ves)

export const catalogoArmas = {
    machete: {
        nombre: 'Machete',
        archivo: './models/MACHETAZO_1.glb',
        durabilidad: 10,
        cooldown: 0.35,        // rápida
        duracionSwing: 0.22,
        rango: 7,
        largoVista: 1.5,
        largoMapa: 2.6,
        pose: {pos: [0.45, -0.4, -0.9], rot: [0.15, 0.5, 0.15]},
    },

    alabarda: {
        nombre: 'Alabarda',
        archivo: './models/ALABARDA.glb',
        durabilidad: 16,       // aguanta más...
        cooldown: 0.9,         // ...pero es lenta y pesada
        duracionSwing: 0.5,
        rango: 10,             // y llega más lejos
        largoVista: 2.6,
        largoMapa: 4.2,
        color: 0xa9b2ba,       // el modelo no trae material: sin esto se vería negro
        pose: {pos: [0.5, -0.55, -0.8], rot: [0.4, 0.4, 0.1]},
    },
};

export const tiposArma = Object.keys(catalogoArmas);
