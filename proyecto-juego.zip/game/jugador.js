import * as THREE from 'three';
import {scene, camera, controls} from './escena.js';
import {estado} from './estado.js';
import {luzJugador} from './luz.js';
import {alturaSuelo} from './terreno.js';
import {terminarJuego} from './hud.js';

//🥀🥀 el cubo del jugador: invisible, solo existe para posición/colisiones
const Cubo = new THREE.BoxGeometry(3, 3, 3);
const Material = new THREE.MeshBasicMaterial({color: 0x000000, side: THREE.DoubleSide});
export const cubo = new THREE.Mesh(Cubo, Material);
cubo.visible = false;
scene.add(cubo);

const alturaJugador = 2.4; // qué tan arriba del suelo está la cámara (los "ojos")

// arranca bien arriba del terreno (no sabemos su altura real todavía: el
// modelo tarda en cargar) y deja que la gravedad lo baje hasta posarse en el
// punto exacto apenas arranque la física — así no hay que calcular la altura
// de aterrizaje a mano
const alturaSpawnInicial = 20;
cubo.position.set(0, alturaSpawnInicial, 0);
camera.position.set(cubo.position.x, cubo.position.y + alturaJugador, cubo.position.z);

const speed = 14; // unidades por segundo
const multiplicadorSprint = 1.8;
const drenadoEstamina = 30; // por segundo mientras corres
const regenEstamina = 15;   // por segundo cuando no corres

//➡️➡️ movimiento
const keys = {};
window.addEventListener('keydown', (event) => {
    keys[event.code] = true;
    if(event.code === 'Space' && enElSuelo){
        velocidadY = fuerzaSalto;
        enElSuelo = false;
    }
});
window.addEventListener('keyup', (event) => { keys[event.code] = false; });

export function mover(delta){
    const seEstaMoviendo = keys['KeyW'] || keys['KeyS'] || keys['KeyA'] || keys['KeyD'];
    const quiereCorrer = keys['ShiftLeft'] || keys['ShiftRight'];
    const puedeCorrer = quiereCorrer && estado.stamina > 0 && seEstaMoviendo;

    let velocidadActual = speed;
    if(puedeCorrer){
        velocidadActual = speed * multiplicadorSprint;
        estado.stamina = Math.max(0, estado.stamina - drenadoEstamina * delta);
    } else {
        estado.stamina = Math.min(estado.maxStamina, estado.stamina + regenEstamina * delta);
    }

    const paso = velocidadActual * delta;

    if(keys['KeyW']) controls.moveForward(paso);
    if(keys['KeyS']) controls.moveForward(-paso);
    if(keys['KeyA']) controls.moveRight(-paso);
    if(keys['KeyD']) controls.moveRight(paso);
}

// 🪂🪂 gravedad y salto
const gravedad = -30;      // unidades por segundo², hacia abajo
const fuerzaSalto = 12;    // impulso vertical al saltar
const alturaVacio = -30;   // si bajas de esto, caíste al vacío entre islas
const penalizacionCaida = 25; // vida que pierdes al caer

let velocidadY = 0;
let enElSuelo = true;

export function actualizarFisica(delta){
    const alturaTerreno = alturaSuelo(camera.position.x, camera.position.z);

    velocidadY += gravedad * delta;
    camera.position.y += velocidadY * delta;

    if(alturaTerreno !== null && camera.position.y <= alturaTerreno + alturaJugador){
        camera.position.y = alturaTerreno + alturaJugador;
        velocidadY = 0;
        enElSuelo = true;
    } else {
        enElSuelo = false;
    }

    if(camera.position.y < alturaVacio){
        caerAlVacio();
    }
}

function caerAlVacio(){
    reaparecerJugador();
    estado.life = Math.max(0, estado.life - penalizacionCaida);
    if(estado.life <= 0 && !estado.juegoTerminado){
        terminarJuego();
    }
}

// te manda al último checkpoint guardado (o al spawn inicial si no activaste
// ninguno). La usa caerAlVacio() y también el botón "Reaparecer" de GAME OVER
export function reaparecerJugador(){
    camera.position.set(estado.checkpoint.x, estado.checkpoint.y, estado.checkpoint.z);
    velocidadY = 0;
    enElSuelo = true;
}

// el cubo sigue a la cámara, y la luz sigue al cubo — se llama una vez por frame
export function sincronizarJugador(){
    cubo.position.x = camera.position.x;
    cubo.position.y = camera.position.y - alturaJugador;
    cubo.position.z = camera.position.z;
    luzJugador.position.set(cubo.position.x, cubo.position.y + 8, cubo.position.z);
}
