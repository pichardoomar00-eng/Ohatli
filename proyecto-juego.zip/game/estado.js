// 📦📦 Estado global del juego.
// Todo lo que cambia con el tiempo (vida, estamina, luz, etc.) vive aquí,
// para que cada módulo pueda leerlo/modificarlo sin tener que importarse
// unos a otros en círculo.

export const estado = {
    life: 100,
    maxLife: 100,

    stamina: 100,
    maxStamina: 100,

    luzDuracion: 100,
    maxLuzDuracion: 100,

    totalspheres: 0,
    tiempoTranscurrido: 0,
    ultimoGolpe: -Infinity,

    tieneArma: false,
    armaActual: null,        // 'machete' | 'alabarda' | ... (llaves de catalogoArmas.js)
    durabilidadArma: 0,
    maxDurabilidadArma: 0,   // lo fija el arma que equipes (ver catalogoArmas.js)

    // punto donde reapareces si caes al vacío — arranca bien arriba del spawn
    // inicial (20 de altura de caída + 2.4 de vista); la gravedad lo corrige
    // solo apenas arranca el juego, así que este valor es solo el respaldo
    // de antes de tocar un checkpoint real
    checkpoint: {x: 0, y: 22.4, z: 0},

    juegoIniciado: false,
    pausado: false,
    juegoTerminado: false,
};

// vuelve los números de la partida a su valor inicial. OJO: no toca
// estado.checkpoint (reaparecer usa el checkpoint ya guardado, no lo borra)
// ni estado.juegoIniciado (seguimos jugando, no volvemos al menú de inicio)
export function reiniciarEstado(){
    estado.life = estado.maxLife;
    estado.stamina = estado.maxStamina;
    estado.luzDuracion = estado.maxLuzDuracion;
    estado.totalspheres = 0;
    estado.ultimoGolpe = -Infinity;
    estado.tieneArma = false;
    estado.armaActual = null;
    estado.durabilidadArma = 0;
    estado.juegoTerminado = false;
    estado.pausado = false;
}
