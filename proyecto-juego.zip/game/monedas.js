import * as THREE from 'three';
import {scene} from './escena.js';
import {cubo} from './jugador.js';
import {estado} from './estado.js';
import {recargaLuzPorMoneda} from './luz.js';
import {actualizarCoinsLabel} from './hud.js';
import {posicionAleatoriaEnIsla, alturaSuelo, terrenoListo} from './terreno.js';

// 🪙🪙🪙 esferas: funcionan como monedas Y como pilas que recargan la luz
const circulo = new THREE.SphereGeometry(1.2, 16, 16); // antes 3: ahora más chicas
const materialmoneda = new THREE.MeshStandardMaterial({color: 0xFFE247, side: THREE.DoubleSide});

const cantidadMonedas = 6;
const alturaSobreElSuelo = 2; // qué tan arriba del terreno flotan

function crearMoneda(x, y, z){
    const moneda = new THREE.Mesh(circulo, materialmoneda);
    moneda.position.set(x, y, z);
    scene.add(moneda);
    return moneda;
}

export const sphereInscene = []; // se llena una vez que el terreno termine de cargar

export const monedasListas = terrenoListo.then(() => {
    for(let i = 0; i < cantidadMonedas; i++){
        const {x, z} = posicionAleatoriaEnIsla();
        sphereInscene.push(crearMoneda(x, (alturaSuelo(x, z) ?? 0) + alturaSobreElSuelo, z));
    }
});

// la llama enemigos.js cuando un enemigo muere, en la posición donde murió
// (ya sobre terreno real, así que usamos directamente su propia altura Y)
export function soltarMoneda(posicion){
    const moneda = crearMoneda(posicion.x, posicion.y + alturaSobreElSuelo, posicion.z);
    sphereInscene.push(moneda);
}

// al "Reaparecer": todas las monedas (incluidas las que sueltan los enemigos) vuelven a estar disponibles
export function reiniciarMonedas(){
    for(let i = 0; i < sphereInscene.length; i++){
        sphereInscene[i].visible = true;
    }
}

export function collect(){
    for(let i = 0; i < sphereInscene.length; i++){
        const currentSphere = sphereInscene[i];
        if(currentSphere.visible){
            const distance = cubo.position.distanceTo(currentSphere.position);
            if(distance < 5){
                currentSphere.visible = false;
                estado.totalspheres += 1;
                estado.luzDuracion = Math.min(estado.maxLuzDuracion, estado.luzDuracion + recargaLuzPorMoneda);
            }
        }
    }
    actualizarCoinsLabel(sphereInscene.length);
}
