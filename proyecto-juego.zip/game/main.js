import * as THREE from 'three';
import {scene, camera, renderer, controls} from './escena.js';
import {estado, reiniciarEstado} from './estado.js';
import {mover, sincronizarJugador, actualizarFisica, reaparecerJugador} from './jugador.js';
import {collect, reiniciarMonedas} from './monedas.js';
import {chase, enemy, actualizarSpawns, actualizarDestellos, actualizarFisicaEnemigos, reiniciarEnemigos} from './enemigos.js';
import {actualizarLuz} from './luz.js';
import {actualizarBarras, actualizarTimer, alReaparecer} from './hud.js';
import {recogerArmas, actualizarArmaVista, actualizarSpawnsArmas, reiniciarArmas} from './armas.js';
import {recogerBotiquines, actualizarSpawnsBotiquines, reiniciarBotiquines} from './botiquines.js';
import {actualizarCheckpoints} from './checkpoints.js';
import './modelos.js'; // el cargador de modelos (GLTFLoader); enemigos.js ya lo usa para el pato
import './menu.js'; // arranca el menú de inicio/pausa; no exporta nada que necesitemos aquí

const reloj = new THREE.Clock();

//🎰🎰 Rendering y animación
function animate(){

    requestAnimationFrame(animate);

    // se llama siempre (menú, pausa o GAME OVER incluidos), para que el reloj
    // no acumule un salto grande de tiempo "fantasma" cuando se reanude/reaparezca
    const delta = reloj.getDelta();

    if(!estado.juegoIniciado || estado.pausado || estado.juegoTerminado){
        renderer.render(scene, camera); // se ve la escena, pero congelada
        return;
    }

    estado.tiempoTranscurrido += delta;

    sincronizarJugador();
    mover(delta);
    actualizarFisica(delta);
    collect();
    recogerArmas();
    actualizarArmaVista(delta);
    actualizarSpawnsArmas();
    recogerBotiquines();
    actualizarSpawnsBotiquines();
    actualizarCheckpoints();
    actualizarFisicaEnemigos(delta);
    chase(delta);
    enemy();
    actualizarSpawns();
    actualizarDestellos();
    actualizarLuz(delta);
    actualizarBarras();
    actualizarTimer();
    renderer.render(scene, camera);
}

animate();

// 🔁🔁 "Reaparecer" en la pantalla de GAME OVER: arma el reinicio completo
// juntando lo que cada módulo expone de sí mismo
function reiniciarJuego(){
    reiniciarEstado();
    reiniciarEnemigos();
    reiniciarMonedas();
    reiniciarArmas();
    reiniciarBotiquines();
    reaparecerJugador();
    actualizarBarras();
    controls.lock();
}

alReaparecer(reiniciarJuego);
