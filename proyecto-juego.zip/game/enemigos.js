import * as THREE from 'three';
import {scene} from './escena.js';
import {cubo} from './jugador.js';
import {estado} from './estado.js';
import {terminarJuego} from './hud.js';
import {soltarMoneda} from './monedas.js';
import {posicionAleatoriaEnIsla, estaSobreIsla, alturaSuelo, terrenoListo} from './terreno.js';
import {cargarPatoClonado} from './modelos.js';

// 💀 enemigos: la esfera queda como "hitbox" invisible (controla posición,
// colisiones y la detección de golpes); el pato que carga modelos.js se
// agrega como hijo y es lo único que en verdad se dibuja.
const circulo2 = new THREE.SphereGeometry(2, 16, 16);
const colorEnemigo = 0x5c0000; // color de respaldo, por si el modelo no llegó a cargar

const vidaMaximaEnemigo = 2; // aguantan 2 golpes
const cantidadEnemigos = 8;
const alturaObjetivoPato = 2.2; // qué tan alto (en unidades del juego) queremos que se vea el pato

// 🧭 el modelo del pato no "mira" hacia -Z por defecto (lo que lookAt() asume),
// así que hay que corregir su rotación para que de verdad apunte al frente.
// Si queda mirando al revés o para el otro lado, cambia el signo o prueba Math.PI.
const correccionRotacionPato = -Math.PI / 2;

function crearEnemigo(){
    const material = new THREE.MeshStandardMaterial({color: colorEnemigo, side: THREE.DoubleSide, transparent: true, opacity: 0});
    const enemigo = new THREE.Mesh(circulo2, material);
    const {x, z} = posicionAleatoriaEnIsla();
    enemigo.position.set(x, alturaSuelo(x, z) ?? 0, z);
    enemigo.userData.vida = vidaMaximaEnemigo;
    enemigo.userData.tiempoEliminado = null; // null = está vivo
    enemigo.userData.flashHasta = 0;
    enemigo.userData.velocidadY = 0;
    enemigo.userData.materialesVisual = []; // se llena cuando el pato termine de cargar
    scene.add(enemigo);

    // la carga es asíncrona: el enemigo ya existe y funciona (persigue, hace daño)
    // desde el primer frame, el pato aparece encima apenas esté listo.
    // En vez de adivinar la escala, medimos el modelo real y lo ajustamos a
    // alturaObjetivoPato — así funciona sin importar qué tan grande venga
    // (incluido el día que pongas tu propio modelo de Blender).
    cargarPatoClonado().then(({modelo, materiales}) => {
        const caja = new THREE.Box3().setFromObject(modelo);
        const alturaNatural = caja.max.y - caja.min.y;
        const escala = alturaNatural > 0 ? alturaObjetivoPato / alturaNatural : 1;

        modelo.scale.setScalar(escala);
        modelo.position.y = -caja.min.y * escala; // que la base del pato quede en el piso del enemigo (y local = 0)
        modelo.rotation.y = correccionRotacionPato; // corrige hacia dónde "mira" el modelo de por sí

        enemigo.add(modelo);
        enemigo.userData.materialesVisual = materiales;
    }).catch((error) => {
        console.error('no se pudo cargar el pato de un enemigo', error);
    });

    return enemigo;
}

export const totalenemies = []; // se llena una vez que el terreno termine de cargar

// el resto del juego (menu.js) espera esta promesa antes de dejar jugar,
// así nunca hay enemigos repartidos sobre un terreno que todavía no existe
export const enemigosListos = terrenoListo.then(() => {
    for(let i = 0; i < cantidadEnemigos; i++){
        totalenemies.push(crearEnemigo());
    }
});

const enemySpeed = 10;        // unidades por segundo
const radioDeteccion = 20;    // solo te persiguen si estás a menos de esto
const radioSeparacion = 4;    // un poco más que el diámetro de un enemigo (radio 2)
const fuerzaSeparacion = 1.5;

// 🪂 gravedad de los enemigos: se llama una vez por frame desde main.js
const gravedadEnemigo = -30;

export function actualizarFisicaEnemigos(delta){
    for(let i = 0; i < totalenemies.length; i++){
        const enemigo = totalenemies[i];
        if(!enemigo.visible) continue;

        const alturaTerreno = alturaSuelo(enemigo.position.x, enemigo.position.z);

        enemigo.userData.velocidadY += gravedadEnemigo * delta;
        enemigo.position.y += enemigo.userData.velocidadY * delta;

        if(alturaTerreno !== null && enemigo.position.y <= alturaTerreno){
            enemigo.position.y = alturaTerreno;
            enemigo.userData.velocidadY = 0;
        }
        // si NO hay isla debajo (se cayó de un puente, por ejemplo), sigue cayendo
        // sin límite — no hace falta más lógica, simplemente no lo vas a volver a ver
    }
}

export function chase(delta){
    const paso = enemySpeed * delta;

    for(let i = 0; i < totalenemies.length; i++){
        const currentenemy = totalenemies[i];
        if(!currentenemy.visible) continue;

        // dirección horizontal hacia el jugador (solo X/Z: la altura ya la
        // resuelve la gravedad en actualizarFisicaEnemigos)
        const dx = cubo.position.x - currentenemy.position.x;
        const dz = cubo.position.z - currentenemy.position.z;
        const distanciaJugador = Math.sqrt(dx * dx + dz * dz);
        if(distanciaJugador > radioDeteccion) continue; // fuera de rango: no te sigue

        // 👀 te voltea a ver aunque esté bloqueado por el borde de la isla
        currentenemy.lookAt(cubo.position.x, currentenemy.position.y, cubo.position.z);

        const direccion = {x: dx / distanciaJugador, z: dz / distanciaJugador};

        // 🧲 separación: se aleja de los enemigos que tiene demasiado cerca
        const separacion = {x: 0, z: 0};
        for(let j = 0; j < totalenemies.length; j++){
            if(j === i) continue;
            const otroEnemigo = totalenemies[j];
            if(!otroEnemigo.visible) continue;

            const ddx = currentenemy.position.x - otroEnemigo.position.x;
            const ddz = currentenemy.position.z - otroEnemigo.position.z;
            const distanciaEntreEnemigos = Math.sqrt(ddx * ddx + ddz * ddz);
            if(distanciaEntreEnemigos < radioSeparacion && distanciaEntreEnemigos > 0){
                separacion.x += ddx / distanciaEntreEnemigos;
                separacion.z += ddz / distanciaEntreEnemigos;
            }
        }
        separacion.x *= fuerzaSeparacion;
        separacion.z *= fuerzaSeparacion;

        let movX = direccion.x + separacion.x;
        let movZ = direccion.z + separacion.z;
        const largoMov = Math.sqrt(movX * movX + movZ * movZ);
        if(largoMov === 0) continue;
        movX = (movX / largoMov) * paso;
        movZ = (movZ / largoMov) * paso;

        // 🧱 no lo dejes caminar fuera de una isla/puente: si el siguiente paso
        // lo saca del suelo firme, se queda parado en el borde (no te sigue al vacío)
        const siguienteX = currentenemy.position.x + movX;
        const siguienteZ = currentenemy.position.z + movZ;
        if(estaSobreIsla(siguienteX, siguienteZ)){
            currentenemy.position.x = siguienteX;
            currentenemy.position.z = siguienteZ;
        }
    }
}

const cooldownGolpe = 1; // segundos de invulnerabilidad después de recibir daño

export function enemy(){
    for(let i = 0; i < totalenemies.length; i++){
        const currentenemy = totalenemies[i];
        if(currentenemy.visible){
            const distance2 = cubo.position.distanceTo(currentenemy.position);
            if(distance2 < 2 && (estado.tiempoTranscurrido - estado.ultimoGolpe) > cooldownGolpe){
                estado.life = Math.max(0, estado.life - 20);
                estado.ultimoGolpe = estado.tiempoTranscurrido;
            }
        }
    }

    if(estado.life <= 0 && !estado.juegoTerminado){
        terminarJuego();
    }
}

const duracionDestello = 0.15; // segundos que dura la retroalimentación visual del golpe
const colorDestello = 0xffffff;
const escalaGolpe = 1.4;

// tiñe TODOS los materiales del pato clonado de un enemigo (puede tener varios:
// cuerpo, pico, ojos...) — si el pato aún no cargó, no hay nada que teñir todavía
function tintarEnemigo(enemigo, color){
    for(let i = 0; i < enemigo.userData.materialesVisual.length; i++){
        enemigo.userData.materialesVisual[i].color.set(color);
    }
}

function restaurarColorEnemigo(enemigo){
    for(let i = 0; i < enemigo.userData.materialesVisual.length; i++){
        const material = enemigo.userData.materialesVisual[i];
        material.color.copy(material.userData.colorOriginal);
    }
}

// ⚔️ le llega un golpe desde armas.js; al segundo golpe muere y suelta una moneda
export function recibirGolpe(enemigo){
    enemigo.userData.vida -= 1;

    // 💥 retroalimentación visual: destello blanco + un "pop" de tamaño (el pop se
    // ve bien aunque el pato no haya cargado, porque escala al hitbox/padre)
    tintarEnemigo(enemigo, colorDestello);
    enemigo.scale.setScalar(escalaGolpe);
    enemigo.userData.flashHasta = estado.tiempoTranscurrido + duracionDestello;

    if(enemigo.userData.vida <= 0){
        soltarMoneda(enemigo.position);
        enemigo.visible = false;
        enemigo.userData.tiempoEliminado = estado.tiempoTranscurrido;
    }
}

// se llama una vez por frame: apaga el destello/"pop" cuando ya pasó su tiempo
export function actualizarDestellos(){
    for(let i = 0; i < totalenemies.length; i++){
        const enemigo = totalenemies[i];
        if(enemigo.userData.flashHasta > 0 && estado.tiempoTranscurrido >= enemigo.userData.flashHasta){
            restaurarColorEnemigo(enemigo);
            enemigo.scale.setScalar(1);
            enemigo.userData.flashHasta = 0;
        }
    }
}

const tiempoRespawn = 8;  // segundos hasta que un enemigo eliminado vuelve a aparecer

// se llama una vez por frame: hace que los enemigos eliminados vuelvan a salir
// en un punto nuevo del mapa después de tiempoRespawn segundos
export function actualizarSpawns(){
    for(let i = 0; i < totalenemies.length; i++){
        const enemigo = totalenemies[i];
        if(enemigo.userData.tiempoEliminado === null) continue;

        const tiempoDesdeQueMurio = estado.tiempoTranscurrido - enemigo.userData.tiempoEliminado;
        if(tiempoDesdeQueMurio >= tiempoRespawn){
            const {x, z} = posicionAleatoriaEnIsla();
            enemigo.position.set(x, alturaSuelo(x, z) ?? 0, z);
            enemigo.userData.vida = vidaMaximaEnemigo;
            enemigo.userData.tiempoEliminado = null;
            enemigo.userData.flashHasta = 0;
            enemigo.userData.velocidadY = 0;
            restaurarColorEnemigo(enemigo);
            enemigo.scale.setScalar(1);
            enemigo.visible = true;
        }
    }
}

// al "Reaparecer": todos los enemigos vuelven a estar completos y visibles donde estaban
export function reiniciarEnemigos(){
    for(let i = 0; i < totalenemies.length; i++){
        const enemigo = totalenemies[i];
        enemigo.userData.vida = vidaMaximaEnemigo;
        enemigo.userData.tiempoEliminado = null;
        enemigo.userData.flashHasta = 0;
        enemigo.userData.velocidadY = 0;
        restaurarColorEnemigo(enemigo);
        enemigo.scale.setScalar(1);
        enemigo.visible = true;
    }
}
