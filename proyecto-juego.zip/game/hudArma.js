import * as THREE from 'three';
import {estado} from './estado.js';
import {catalogoArmas} from './catalogoArmas.js';
import {crearModeloArma} from './armaModelo.js';

// 🗡️🗡️ HUD del arma equipada. El HTML/CSS vive en ArchivoBase.html y hud.css;
// aquí solo se conecta con el juego. Dibuja el modelo REAL del arma en un
// mini-visor 3D propio (un segundo renderer chiquito), así el ícono siempre
// coincide con el modelo de Blender y no hay que hacer imágenes aparte.

const panel = document.getElementById('hud-arma');
const canvas = document.getElementById('hud-arma-canvas');
const nombre = document.getElementById('hud-arma-nombre');
const relleno = document.getElementById('hud-arma-relleno');
const usos = document.getElementById('hud-arma-usos');
const aviso = document.getElementById('hud-interaccion');

// ── mini-visor 3D ──────────────────────────────────────────────
const tamanoVisor = 150;
const renderer = new THREE.WebGLRenderer({canvas, alpha: true, antialias: true});
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setSize(tamanoVisor, tamanoVisor, false); // el tamaño en pantalla lo da el CSS
renderer.setClearColor(0x000000, 0);               // fondo transparente

const escenaVisor = new THREE.Scene();
const camaraVisor = new THREE.PerspectiveCamera(30, 1, 0.1, 50);
camaraVisor.position.set(0, 0, 7.5);

escenaVisor.add(new THREE.AmbientLight(0xffffff, 0.8));
const luzVisor = new THREE.DirectionalLight(0xffffff, 1.2);
luzVisor.position.set(3, 4, 5);
escenaVisor.add(luzVisor);

// giro → inclinación → vertical → arma. El arma sale apuntando a -Z; "vertical"
// la para de punta, "inclinado" la ladea, y "giro" la hace girar sobre sí misma.
const giro = new THREE.Group();
const inclinado = new THREE.Group();
const vertical = new THREE.Group();
const largoIcono = 3.2;

vertical.rotation.x = Math.PI / 2;
vertical.position.y = -largoIcono / 2;
inclinado.rotation.z = -0.35;
inclinado.add(vertical);
giro.add(inclinado);
escenaVisor.add(giro);

let modeloActual = null;
let versionVisor = 0; // evita que una carga lenta pise a una más reciente

function limpiarModeloVisor(){
    if(!modeloActual) return;
    vertical.remove(modeloActual);
    modeloActual.traverse((hijo) => {
        if(hijo.isMesh) hijo.material.dispose();
    });
    modeloActual = null;
}

// ── API ────────────────────────────────────────────────────────
export function mostrarArmaHud(tipo){
    const def = catalogoArmas[tipo];
    nombre.textContent = def.nombre;
    panel.classList.remove('oculto-hud');
    actualizarHudArma(0);

    const miVersion = ++versionVisor;
    limpiarModeloVisor();
    crearModeloArma(tipo, largoIcono, false).then((modelo) => {
        if(miVersion !== versionVisor){ // mientras cargaba, se cambió o se soltó el arma
            modelo.traverse((hijo) => { if(hijo.isMesh) hijo.material.dispose(); });
            return;
        }
        modeloActual = modelo;
        vertical.add(modelo);
    }).catch((error) => console.error('No se pudo armar el ícono del arma:', error));
}

export function ocultarArmaHud(){
    versionVisor++;
    panel.classList.add('oculto-hud');
    limpiarModeloVisor();
}

// se llama una vez por frame: barra de aguante + giro del ícono
export function actualizarHudArma(delta){
    if(panel.classList.contains('oculto-hud') || !estado.armaActual) return;

    const max = estado.maxDurabilidadArma;
    const actual = estado.durabilidadArma;
    const proporcion = max > 0 ? actual / max : 0;

    relleno.style.width = `${Math.max(0, proporcion * 100)}%`;
    relleno.style.backgroundColor = proporcion > 0.5 ? '#2ecc71' : (proporcion > 0.25 ? '#ffd60a' : '#e63946');
    usos.textContent = `${actual} / ${max}`;

    giro.rotation.y += delta * 1.2;
    renderer.render(escenaVisor, camaraVisor);
}

// 💬 aviso "[E] Recoger ..." cuando estás cerca de un arma del mapa
let textoAviso = '';
export function mostrarAviso(texto){
    if(texto === textoAviso) return;
    textoAviso = texto;
    aviso.textContent = texto;
    aviso.classList.remove('oculto-hud');
}

export function ocultarAviso(){
    if(textoAviso === '') return;
    textoAviso = '';
    aviso.classList.add('oculto-hud');
}
