import * as THREE from 'three';
import {scene, camera, controls} from './escena.js';
import {cubo} from './jugador.js';
import {estado} from './estado.js';
import {totalenemies, recibirGolpe} from './enemigos.js';
import {posicionAleatoriaEnIsla, alturaSuelo, terrenoListo} from './terreno.js';
import {catalogoArmas, tiposArma} from './catalogoArmas.js';
import {crearModeloArma} from './armaModelo.js';
import {precargarModelo} from './modelos.js';
import {mostrarArmaHud, ocultarArmaHud, actualizarHudArma, mostrarAviso, ocultarAviso} from './hudArma.js';

// ═══════════════════════════════════════════════════════════════
//  🗡️🗡️ ARMAS EN EL MAPA (recogibles)
// ═══════════════════════════════════════════════════════════════
const cantidadArmas = 4;          // se reparten por turnos entre los tipos del catálogo
const tiempoRespawnArma = 15;     // segundos hasta que un arma recogida vuelve a aparecer
const alturaSobreElSuelo = 2;
const distanciaRecoleccion = 4.5;

// cada arma del mapa es un Group (posición/visibilidad/tipo) con el modelo
// real adentro. El modelo carga en segundo plano: el arma ya existe y se puede
// recoger desde el primer frame, el modelo aparece apenas esté listo.
function crearArmaDelMapa(indice){
    const tipo = tiposArma[indice % tiposArma.length];
    const def = catalogoArmas[tipo];

    const arma = new THREE.Group();
    const {x, z} = posicionAleatoriaEnIsla();
    arma.position.set(x, (alturaSuelo(x, z) ?? 0) + alturaSobreElSuelo, z);
    arma.userData.tipo = tipo;
    arma.userData.tiempoRecogido = null; // null = disponible
    scene.add(arma);

    crearModeloArma(tipo, def.largoMapa, false).then((modelo) => {
        // el modelo sale apuntando a -Z con el mango en el origen: lo paramos de
        // punta y lo centramos para que gire sobre sí mismo en el aire
        const vertical = new THREE.Group();
        vertical.rotation.x = Math.PI / 2;
        vertical.position.y = -def.largoMapa / 2;
        vertical.add(modelo);
        arma.add(vertical);
    }).catch((error) => console.error(`No se pudo armar el arma del mapa (${tipo}):`, error));

    return arma;
}

export const armasEnMapa = []; // se llena una vez que el terreno termine de cargar

// el menú espera esta promesa: también descarga los modelos de las armas, así
// un archivo faltante se avisa desde el inicio y no cuando ya estás jugando
export const armasListas = terrenoListo.then(() => {
    for(let i = 0; i < cantidadArmas; i++){
        armasEnMapa.push(crearArmaDelMapa(i));
    }
    return Promise.all(tiposArma.map((tipo) => precargarModelo(catalogoArmas[tipo].archivo)));
});

// ═══════════════════════════════════════════════════════════════
//  👁️🗡️ ARMA EN TU MANO (primera persona)
// ═══════════════════════════════════════════════════════════════
// Un Group hijo de la cámara (se mueve y gira contigo) que sostiene el modelo
// del arma equipada. La pose de reposo cambia con cada arma (ver catálogo).
const armaVista = new THREE.Group();
armaVista.visible = false;
camera.add(armaVista);

const posicionReposo = new THREE.Vector3();
const rotacionReposo = new THREE.Euler();

let modeloVista = null;
let versionVista = 0;      // evita que una carga lenta pise a una más reciente
let swingActivo = false;
let swingElapsed = 0;
let duracionSwingActual = 0.3;
let rotaPendiente = false; // el arma se rompió: se esconde cuando termine el golpe
let ultimoAtaque = -Infinity;

function liberarModelo(modelo){
    modelo.traverse((hijo) => {
        if(hijo.isMesh) hijo.material.dispose();
    });
}

function quitarModeloVista(){
    if(!modeloVista) return;
    armaVista.remove(modeloVista);
    liberarModelo(modeloVista);
    modeloVista = null;
}

function mostrarEnVista(tipo){
    const def = catalogoArmas[tipo];
    const miVersion = ++versionVista;

    swingActivo = false;
    quitarModeloVista();

    posicionReposo.set(...def.pose.pos);
    rotacionReposo.set(...def.pose.rot);
    armaVista.position.copy(posicionReposo);
    armaVista.rotation.copy(rotacionReposo);

    crearModeloArma(tipo, def.largoVista, true).then((modelo) => {
        if(miVersion !== versionVista){ // mientras cargaba, se cambió o se rompió el arma
            liberarModelo(modelo);
            return;
        }
        modeloVista = modelo;
        armaVista.add(modelo);
        armaVista.visible = true;
    }).catch((error) => console.error(`No se pudo armar el arma en mano (${tipo}):`, error));
}

function ocultarVista(){
    versionVista++;
    quitarModeloVista();
    armaVista.visible = false;
    swingActivo = false;
}

// ═══════════════════════════════════════════════════════════════
//  🎒 EQUIPAR / ROMPER
// ═══════════════════════════════════════════════════════════════
function equiparArma(tipo){
    const def = catalogoArmas[tipo];

    estado.armaActual = tipo;
    estado.tieneArma = true;
    estado.maxDurabilidadArma = def.durabilidad;
    estado.durabilidadArma = def.durabilidad;
    rotaPendiente = false;

    mostrarEnVista(tipo);
    mostrarArmaHud(tipo);
}

function soltarArma(){
    rotaPendiente = false;
    ocultarVista();
    ocultarArmaHud();
}

function romperArma(){
    estado.tieneArma = false;
    estado.armaActual = null;

    // si todavía va a medio golpe, deja que termine la animación antes de esconderla
    if(swingActivo){
        rotaPendiente = true;
    } else {
        soltarArma();
    }
}

// ═══════════════════════════════════════════════════════════════
//  ✋ RECOGER (con la tecla E)
// ═══════════════════════════════════════════════════════════════
// Con dos tipos de arma, recoger "al pasar encima" te quitaría sin querer un
// arma a medio gastar. Por eso es una decisión: te acercas, aparece el aviso
// y presionas E.
let quiereRecoger = false;

document.addEventListener('keydown', (event) => {
    if(event.code !== 'KeyE') return;
    if(!estado.juegoIniciado || estado.pausado || estado.juegoTerminado) return;
    quiereRecoger = true;
});

// se llama una vez por frame
export function recogerArmas(){
    let cercana = null;
    let menorDistancia = distanciaRecoleccion;

    for(let i = 0; i < armasEnMapa.length; i++){
        const arma = armasEnMapa[i];
        if(!arma.visible) continue;
        const distancia = cubo.position.distanceTo(arma.position);
        if(distancia < menorDistancia){
            menorDistancia = distancia;
            cercana = arma;
        }
    }

    if(!cercana){
        ocultarAviso();
        quiereRecoger = false;
        return;
    }

    const tipo = cercana.userData.tipo;
    mostrarAviso(`[E]  Recoger ${catalogoArmas[tipo].nombre}`);

    if(quiereRecoger){
        quiereRecoger = false;
        cercana.visible = false;
        cercana.userData.tiempoRecogido = estado.tiempoTranscurrido;
        equiparArma(tipo);
        ocultarAviso();
    }
}

// se llama una vez por frame: las armas del mapa giran para que se noten, y las
// recogidas reaparecen en un punto nuevo después de tiempoRespawnArma segundos
export function actualizarSpawnsArmas(){
    for(let i = 0; i < armasEnMapa.length; i++){
        const arma = armasEnMapa[i];

        if(arma.visible){
            arma.rotation.y = estado.tiempoTranscurrido * 1.5;
            continue;
        }
        if(arma.userData.tiempoRecogido === null) continue;

        const tiempoDesdeRecogida = estado.tiempoTranscurrido - arma.userData.tiempoRecogido;
        if(tiempoDesdeRecogida >= tiempoRespawnArma){
            const {x, z} = posicionAleatoriaEnIsla();
            arma.position.set(x, (alturaSuelo(x, z) ?? 0) + alturaSobreElSuelo, z);
            arma.userData.tiempoRecogido = null;
            arma.visible = true;
        }
    }
}

// al "Reaparecer": todas las armas del mapa vuelven a estar disponibles,
// y el jugador pierde la que traía (vuelve a necesitar recoger una)
export function reiniciarArmas(){
    for(let i = 0; i < armasEnMapa.length; i++){
        armasEnMapa[i].visible = true;
        armasEnMapa[i].userData.tiempoRecogido = null;
    }
    quiereRecoger = false;
    ocultarAviso();
    soltarArma();
}

// ═══════════════════════════════════════════════════════════════
//  💥 GOLPEAR
// ═══════════════════════════════════════════════════════════════
const anguloAtaque = Math.PI / 4; // "cono" de 45° hacia donde miras

// 🗡️💨 animación de golpe: una curva simple (seno) con un barrido de lado a
// lado. Su duración sale del arma equipada: la alabarda se siente pesada y
// lenta, el machete ágil.
function iniciarSwing(duracion){
    duracionSwingActual = duracion;
    swingActivo = true;
    swingElapsed = 0;
}

// se llama una vez por frame desde main.js
export function actualizarArmaVista(delta){
    actualizarHudArma(delta);

    if(!swingActivo) return;

    swingElapsed += delta;
    const progreso = Math.min(swingElapsed / duracionSwingActual, 1);
    const fuerza = Math.sin(progreso * Math.PI); // sube y vuelve a bajar: 0 → 1 → 0

    armaVista.rotation.y = rotacionReposo.y - fuerza * 1.3;  // barrido de lado a lado
    armaVista.rotation.x = rotacionReposo.x - fuerza * 0.5;  // un poco hacia abajo
    armaVista.position.z = posicionReposo.z + fuerza * 0.25; // se adelanta

    if(progreso >= 1){
        swingActivo = false;
        armaVista.rotation.copy(rotacionReposo);
        armaVista.position.copy(posicionReposo);
        if(rotaPendiente) soltarArma();
    }
}

// busca, entre los enemigos visibles y dentro del cono/rango de ataque,
// al más cercano, y le pega
function atacar(){
    if(!estado.tieneArma) return;
    if(!controls.isLocked) return; // evita que el primer click (el que activa el mouse) cuente como golpe

    const def = catalogoArmas[estado.armaActual];
    if((estado.tiempoTranscurrido - ultimoAtaque) < def.cooldown) return;

    ultimoAtaque = estado.tiempoTranscurrido;
    iniciarSwing(def.duracionSwing); // la animación se ve siempre que atacas, conectes o no

    // 🔧 durabilidad: cada golpe desgasta el arma, conecte o no
    estado.durabilidadArma = Math.max(0, estado.durabilidadArma - 1);
    actualizarHudArma(0); // refleja el desgaste de inmediato (incluido el 0 antes de romperse)
    if(estado.durabilidadArma <= 0){
        romperArma();
    }

    const direccionCamara = new THREE.Vector3();
    camera.getWorldDirection(direccionCamara);

    let enemigoMasCercano = null;
    let menorDistancia = Infinity;

    for(let i = 0; i < totalenemies.length; i++){
        const enemigo = totalenemies[i];
        if(!enemigo.visible) continue;

        const haciaEnemigo = new THREE.Vector3().subVectors(enemigo.position, camera.position);
        const distancia = haciaEnemigo.length();
        if(distancia > def.rango) continue;

        haciaEnemigo.normalize();
        const angulo = direccionCamara.angleTo(haciaEnemigo);
        if(angulo > anguloAtaque) continue;

        if(distancia < menorDistancia){
            menorDistancia = distancia;
            enemigoMasCercano = enemigo;
        }
    }

    if(enemigoMasCercano){
        recibirGolpe(enemigoMasCercano);
    }
}

document.addEventListener('mousedown', atacar);
