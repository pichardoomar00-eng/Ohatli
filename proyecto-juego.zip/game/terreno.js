import * as THREE from 'three';
import {GLTFLoader} from 'three/GLTFLoader';
import {scene} from './escena.js';

const cargador = new GLTFLoader();

// 🏝️🏝️ islas modeladas en Blender. Cada entrada es UNA COPIA de un modelo,
// colocada en una posición/escala/rotación — conforme vayan llegando más
// islas, se agregan aquí como entradas nuevas (mismo archivo repetido o
// archivos distintos, da igual).
const colocaciones = [
    {archivo: './models/isla_m2.glb', x: 0, y: 0, z: 0, escala: 3, rotacionY: 0},
];

const colisionables = []; // las mallas reales contra las que se dispara el rayo
let cajaTotal = null;      // bounding box de TODAS las islas juntas, para repartir spawns

function cargarColocacion(colocacion){
    return new Promise((resolve, reject) => {
        cargador.load(
            colocacion.archivo,
            (gltf) => {
                const modelo = gltf.scene;
                modelo.position.set(colocacion.x, colocacion.y, colocacion.z);
                modelo.rotation.y = colocacion.rotacionY ?? 0;
                modelo.scale.setScalar(colocacion.escala ?? 1);
                scene.add(modelo);

                modelo.traverse((hijo) => {
                    if(hijo.isMesh){
                        colisionables.push(hijo);
                    }
                });

                const caja = new THREE.Box3().setFromObject(modelo);
                cajaTotal = cajaTotal ? cajaTotal.union(caja) : caja;

                resolve(modelo);
            },
            undefined,
            (error) => {
                console.error(`❌ no se pudo cargar la isla: ${colocacion.archivo}`, error);
                reject(error);
            }
        );
    });
}

// se resuelve cuando TODAS las islas terminaron de cargar. El menú (menu.js)
// espera esto antes de dejar presionar "Jugar" — así nadie empieza a jugar
// con el terreno todavía incompleto.
export const terrenoListo = Promise.all(colocaciones.map(cargarColocacion));

// 🎯 raycasting: tira un rayo hacia abajo en (x, z) y devuelve la altura (Y)
// del punto sólido más alto ahí debajo, o null si no hay nada debajo (vacío).
// Esto reemplaza al viejo sistema de rectángulos: funciona sin importar qué
// tan irregular sea la forma de la isla.
const raycaster = new THREE.Raycaster();
const direccionAbajo = new THREE.Vector3(0, -1, 0);
const alturaInicioRayo = 200; // bien arriba de cualquier isla, para no empezar el rayo "adentro" del modelo

export function alturaSuelo(x, z){
    raycaster.set(new THREE.Vector3(x, alturaInicioRayo, z), direccionAbajo);
    const intersecciones = raycaster.intersectObjects(colisionables, false);
    return intersecciones.length > 0 ? intersecciones[0].point.y : null;
}

export function estaSobreIsla(x, z){
    return alturaSuelo(x, z) !== null;
}

// una posición aleatoria sobre suelo sólido REAL (confirmado con el rayo, no
// solo "dentro del rectángulo"), para repartir enemigos/monedas/armas/botiquines
export function posicionAleatoriaEnIsla(intentosMax = 30){
    if(!cajaTotal) return {x: 0, z: 0}; // respaldo si se llama antes de que cargue el terreno

    for(let intento = 0; intento < intentosMax; intento++){
        const x = cajaTotal.min.x + Math.random() * (cajaTotal.max.x - cajaTotal.min.x);
        const z = cajaTotal.min.z + Math.random() * (cajaTotal.max.z - cajaTotal.min.z);
        if(estaSobreIsla(x, z)) return {x, z};
    }
    return {x: cajaTotal.min.x, z: cajaTotal.min.z}; // no encontró suelo en los intentos: respaldo
}
