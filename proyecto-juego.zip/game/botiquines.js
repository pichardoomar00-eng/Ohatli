import * as THREE from 'three';
import {scene} from './escena.js';
import {cubo} from './jugador.js';
import {estado} from './estado.js';
import {posicionAleatoriaEnIsla, alturaSuelo, terrenoListo} from './terreno.js';

// ⛑️⛑️ botiquines: curan vida, reactivos a la luz como todo lo demás en el mapa
const geometriaBotiquin = new THREE.BoxGeometry(1.2, 1.2, 1.2);

const cantidadBotiquines = 4;
const curacion = 40;
const distanciaRecoleccion = 4;
const tiempoRespawn = 12;   // segundos hasta que vuelve a aparecer tras ser recogido
const alturaSobreElSuelo = 2;

function crearBotiquin(){
    const {x, z} = posicionAleatoriaEnIsla();
    // cada uno con su propio material (misma lección que con los enemigos:
    // si algún día le agregamos un destello al recogerlo, no afecta a los demás)
    const material = new THREE.MeshStandardMaterial({color: 0xe63946, side: THREE.DoubleSide});
    const botiquin = new THREE.Mesh(geometriaBotiquin, material);
    botiquin.position.set(x, (alturaSuelo(x, z) ?? 0) + alturaSobreElSuelo, z);
    botiquin.userData.tiempoRecogido = null; // null = disponible
    scene.add(botiquin);
    return botiquin;
}

export const botiquinesEnMapa = []; // se llena una vez que el terreno termine de cargar

export const botiquinesListos = terrenoListo.then(() => {
    for(let i = 0; i < cantidadBotiquines; i++){
        botiquinesEnMapa.push(crearBotiquin());
    }
});

// se llama una vez por frame: revisa si el jugador está sobre un botiquín
export function recogerBotiquines(){
    for(let i = 0; i < botiquinesEnMapa.length; i++){
        const botiquin = botiquinesEnMapa[i];
        if(botiquin.visible){
            const distancia = cubo.position.distanceTo(botiquin.position);
            if(distancia < distanciaRecoleccion){
                estado.life = Math.min(estado.maxLife, estado.life + curacion);
                botiquin.visible = false;
                botiquin.userData.tiempoRecogido = estado.tiempoTranscurrido;
            }
        }
    }
}

// al "Reaparecer": todos los botiquines vuelven a estar disponibles
export function reiniciarBotiquines(){
    for(let i = 0; i < botiquinesEnMapa.length; i++){
        botiquinesEnMapa[i].visible = true;
        botiquinesEnMapa[i].userData.tiempoRecogido = null;
    }
}

// se llama una vez por frame: hace reaparecer, en un punto nuevo del mapa,
// a los botiquines que ya fueron recogidos hace tiempoRespawn segundos o más
export function actualizarSpawnsBotiquines(){
    for(let i = 0; i < botiquinesEnMapa.length; i++){
        const botiquin = botiquinesEnMapa[i];
        if(botiquin.userData.tiempoRecogido === null) continue;

        const tiempoDesdeRecogido = estado.tiempoTranscurrido - botiquin.userData.tiempoRecogido;
        if(tiempoDesdeRecogido >= tiempoRespawn){
            const {x, z} = posicionAleatoriaEnIsla();
            botiquin.position.set(x, (alturaSuelo(x, z) ?? 0) + alturaSobreElSuelo, z);
            botiquin.userData.tiempoRecogido = null;
            botiquin.visible = true;
        }
    }
}
