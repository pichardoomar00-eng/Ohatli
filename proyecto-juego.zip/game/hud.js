import {estado} from './estado.js';

//📋📋 barra genérica reutilizable
function crearBarra(top, colorRelleno){
    const contenedor = document.createElement('div');
    contenedor.style.position = 'absolute';
    contenedor.style.top = top;
    contenedor.style.left = '20px';
    contenedor.style.width = '200px';
    contenedor.style.height = '22px';
    contenedor.style.backgroundColor = 'rgba(0,0,0,0.6)';
    contenedor.style.border = '2px solid white';
    contenedor.style.borderRadius = '8px';
    contenedor.style.overflow = 'hidden';
    document.body.appendChild(contenedor);

    const relleno = document.createElement('div');
    relleno.style.height = '100%';
    relleno.style.width = '100%';
    relleno.style.backgroundColor = colorRelleno;
    relleno.style.transition = 'width 0.1s linear';
    contenedor.appendChild(relleno);

    return relleno;
}

const vidaBarraRelleno = crearBarra('70px', '#e63946');       // rojo
const staminaBarraRelleno = crearBarra('105px', '#ffd60a');   // amarillo
const luzBarraRelleno = crearBarra('140px', '#00b4d8');       // azul

export function actualizarBarras(){
    vidaBarraRelleno.style.width = `${Math.max(0, (estado.life / estado.maxLife) * 100)}%`;
    staminaBarraRelleno.style.width = `${Math.max(0, (estado.stamina / estado.maxStamina) * 100)}%`;
    luzBarraRelleno.style.width = `${Math.max(0, (estado.luzDuracion / estado.maxLuzDuracion) * 100)}%`;
}

//🪙🪙 contador de monedas
const totatCoinsLebel = document.createElement('div');
totatCoinsLebel.style.position = 'absolute';
totatCoinsLebel.style.top = '20px';
totatCoinsLebel.style.left = '20px';
totatCoinsLebel.style.color = 'white';
totatCoinsLebel.style.fontSize = '24px';
totatCoinsLebel.style.fontFamily = 'Arial';
totatCoinsLebel.style.padding = '10px 15px';
totatCoinsLebel.style.backgroundColor = 'rgba(0,0,0,0.6)';
totatCoinsLebel.style.borderRadius = '8px';
document.body.appendChild(totatCoinsLebel);

export function actualizarCoinsLabel(totalMonedasEnMapa){
    totatCoinsLebel.textContent = `Coins: ${estado.totalspheres} / ${totalMonedasEnMapa}`;
}

//⏱️⏱️ tiempo (la etiqueta se crea una sola vez, no en cada frame)
const timerLebel = document.createElement('div');
timerLebel.style.position = 'absolute';
timerLebel.style.top = '20px';
timerLebel.style.left = '200px';
timerLebel.style.color = 'white';
timerLebel.style.fontSize = '24px';
timerLebel.style.fontFamily = 'Arial';
timerLebel.style.padding = '10px 15px';
timerLebel.style.backgroundColor = 'rgba(0,0,0,0.6)';
timerLebel.style.borderRadius = '8px';
document.body.appendChild(timerLebel);

const tiempoLimite = 15;
export function actualizarTimer(){
    const restante = Math.max(0, tiempoLimite - estado.tiempoTranscurrido);
    timerLebel.textContent = `tiempo: ${Math.ceil(restante)}`;
    if(restante === 0){
        console.log('fin del tiempo');
    }
}

// 💀 pantalla de fin de juego
const gameOverLebel = document.createElement('div');
gameOverLebel.style.position = 'absolute';
gameOverLebel.style.top = '0';
gameOverLebel.style.left = '0';
gameOverLebel.style.width = '100%';
gameOverLebel.style.height = '100%';
gameOverLebel.style.display = 'none';
gameOverLebel.style.flexDirection = 'column';
gameOverLebel.style.alignItems = 'center';
gameOverLebel.style.justifyContent = 'center';
gameOverLebel.style.gap = '24px';
gameOverLebel.style.color = 'white';
gameOverLebel.style.fontFamily = 'Arial';
gameOverLebel.style.backgroundColor = 'rgba(0,0,0,0.85)';
document.body.appendChild(gameOverLebel);

const gameOverTitulo = document.createElement('div');
gameOverTitulo.textContent = 'GAME OVER';
gameOverTitulo.style.fontSize = '64px';
gameOverLebel.appendChild(gameOverTitulo);

// reutiliza el mismo estilo de botón que los menús (definido en menu.css,
// ya está enlazado globalmente en el <head> del HTML)
const botonReaparecer = document.createElement('button');
botonReaparecer.textContent = 'Reaparecer';
botonReaparecer.className = 'menu-boton';
gameOverLebel.appendChild(botonReaparecer);

// hud.js solo se encarga de ocultar su propia pantalla; el reinicio real
// del juego (vida, enemigos, posición, etc.) lo arma main.js y se engancha
// aquí con alReaparecer(), para no tener que importar medio juego desde hud.js
botonReaparecer.addEventListener('click', () => {
    gameOverLebel.style.display = 'none';
});

export function alReaparecer(callback){
    botonReaparecer.addEventListener('click', callback);
}

export function terminarJuego(){
    estado.juegoTerminado = true;
    gameOverLebel.style.display = 'flex';
    document.exitPointerLock();
}
