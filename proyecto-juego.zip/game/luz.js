import * as THREE from 'three';
import {scene} from './escena.js';
import {estado} from './estado.js';
import {terminarJuego} from './hud.js';

// 💡💡 luz que sigue al jugador
export const luzJugador = new THREE.PointLight(0xffffff, 3, 40);
scene.add(luzJugador);

// luz base tenue para que el mapa no sea negro absoluto
export const luzAmbiental = new THREE.AmbientLight(0x404040, 0.08);
scene.add(luzAmbiental);

const intensidadBaseLuz = 3; // la intensidad original de luzJugador
const drenadoLuz = 4;        // por segundo
export const recargaLuzPorMoneda = 25;

// 🔋 la luz se va agotando con el tiempo; las monedas la recargan (ver monedas.js)
export function actualizarLuz(delta){
    estado.luzDuracion = Math.max(0, estado.luzDuracion - drenadoLuz * delta);
    luzJugador.intensity = intensidadBaseLuz * (estado.luzDuracion / estado.maxLuzDuracion);

    if(estado.luzDuracion <= 0 && !estado.juegoTerminado){
        terminarJuego();
    }
}
